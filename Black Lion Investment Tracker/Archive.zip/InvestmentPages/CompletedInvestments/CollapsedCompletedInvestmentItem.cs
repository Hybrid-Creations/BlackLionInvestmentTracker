using BLIT.Investments;

namespace BLIT.UI;

// public sealed partial class CollapsedCompletedInvestmentItem : CollapsedInvestmentItemm<CollapsedCompletedInvestment, CompletedInvestment, CompletedInvestmentData, BuyData, SellData, CompletedInvsetmentItem>
// {
//     protected override void OnMarkedNotAnInvestment()
//     {
//         Main.Database.CollapsedCompletedInvestments.Remove(collapsedInvestment);

//         foreach (var investment in collapsedInvestment.SubInvestments)
//         {
//             Main.Database.CompletedInvestments.Remove(investment);
//             Main.Database.NotInvestments.Add(investment.Data.BuyData.TransactionId);
//         }
//     }
// }
