using BLIT.Investments;

namespace BLIT.UI;

// public partial class CompletedInvsetmentItem : InvestmentItem<CompletedInvestment, CompletedInvestmentData, BuyData, SellData>
// {
// }
