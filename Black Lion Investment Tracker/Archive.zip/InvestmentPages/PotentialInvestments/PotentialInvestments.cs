
using BLIT.Investments;

namespace BLIT.UI;

public partial class PotentialInvestments : InvestmentPageeee<CollapsedPotentialnvestment, PotentialInvestment, PotentialInvestmentData, BuyData, SellData>
{

}
